# LMS
Seperate pages for Admin and User have been created and Menu bar's have been added.
run(fn+F5) ->  main.dart 
(to run the code)
